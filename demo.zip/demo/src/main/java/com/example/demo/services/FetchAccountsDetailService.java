package com.example.demo.services;

import com.example.demo.model.Account;

import java.util.List;

public interface FetchAccountsDetailService {
    public List getAccountDetails();
    public Account getAccountDetailById(int id);
}
