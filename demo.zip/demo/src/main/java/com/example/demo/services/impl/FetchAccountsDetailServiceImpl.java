package com.example.demo.services.impl;

import com.example.demo.model.Account;
import com.example.demo.services.FetchAccountsDetailService;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

@Service
public class FetchAccountsDetailServiceImpl implements FetchAccountsDetailService {

    public List getAccountDetails(){
        return getAllAccounts();
    }


    public Account getAccountDetailById(int id){

        List<Account>  accountList= getAllAccounts();
        Account account = accountList.stream().filter(t->t.getId() ==id).collect(Collectors.toList()).get(0);
        return account;

    }

    private List getAllAccounts(){

        List<Account>  accountList= new ArrayList<>();
        Account account = new Account();
        account.setId(1);
        account.setName("Rupesh");


        Account account2 = new Account();
        account2.setId(2);
        account2.setName("Atul");

        accountList.add(account);
        accountList.add(account2);
        return accountList;
    }


}
