package com.example.demo.controllers;


import com.example.demo.model.Account;
import com.example.demo.services.FetchAccountsDetailService;
import com.example.demo.services.impl.FetchAccountsDetailServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController()
@RequestMapping(value = "/accounts")
public class DemoController {

    @Autowired
    FetchAccountsDetailServiceImpl fetchAccountsDetailServiceImpl;

    @GetMapping("")
    public List getAccounts(){
        return fetchAccountsDetailServiceImpl.getAccountDetails();
    }

    @GetMapping("/{id}")
    public Account getAccounts(@PathVariable int id){
        return fetchAccountsDetailServiceImpl.getAccountDetailById(id);
    }


}
